document.getElementById('issueInputForm').addEventListener('submit', saveIssue);

function saveIssue(e) {
  var issueId = chance.guid();
  var issueDesc = document.getElementById('issueDescInput').value;
  var issueSeverity = document.getElementById('issueSeverityInput').value;
  var issueAssignedTo = document.getElementById('issueAssignedToInput').value;
  var issueStatus = '-- ';

   var issue = {
    id: issueId,
    description: issueDesc,
    severity: issueSeverity,
    assignedTo: issueAssignedTo,
   status: issueStatus
  }
  
if (localStorage.getItem('issues') === null) {
    var issues = [];
    issues.push(issue);
    localStorage.setItem('issues', JSON.stringify(issues));
  } else {
    var issues = JSON.parse(localStorage.getItem('issues'));
    issues.push(issue);
    localStorage.setItem('issues', JSON.stringify(issues));
  }

 
  document.getElementById('issueInputForm').reset();
 
  fetchReview();
  
  e.preventDefault(); 
}


function fetchReview () {

  var issues = JSON.parse(localStorage.getItem('issues'));
  var reviewList = document.getElementById('reviewList');
  
  reviewList.innerHTML = '';
  
  for (var i = 0; i < issues.length; i++) {
    var id = issues[i].id;
    var desc = issues[i].description;
    var severity = issues[i].severity;
    var assignedTo = issues[i].assignedTo;
    var status = issues[i].status;

 
    
    reviewList.innerHTML +=   '<div class="well">'+
                              '<h6>Entry ID: ' + id + '</h6>'+
                              '<p><span class="label label-info">' + status + '</span></p>'+
				//'<h3>' + desc + '</h3>'+
                              '<p><span class="glyphicon glyphicon-star"></span> ' + severity + ' '+
                              '<span class="glyphicon glyphicon-user"></span> ' + assignedTo + '</p>'+
			      '<a href="#" class="btn btn-warning" onclick="getRating(\''+id+'\')">Review Comment</a> '
                                  '</div>';
  }
}
function getRating (id) {

var issues = JSON.parse(localStorage.getItem('issues'));
  
  for(var i = 0; i < issues.length; i++) {
    if (issues[i].id == id) {
      issues[i].status = issues[i].description;
    }
  }
     localStorage.setItem('issues', JSON.stringify(issues));

  fetchReview();


//Submit data when enter key is pressed
        $("button").click(function(e){
        	var name = $('#issueSeverityInput').val();
		var desc =  $('# issueDescInput').val();
		
            if (e.which == 13 && name.length > 0) { //catch Enter key
            	//POST request to API to create a new visitor entry in the database
                $.ajax({
				  method: "POST",
				  url: "./api/visitors",
				  contentType: "application/json",
				  data: JSON.stringify({name: name,desc:desc })
				})
                .done(function(data) {
                    if(data && data.name){
                        if(data._id)
                            $('#response').html($.i18n('added_to_database', AntiXSS.sanitizeInput(data.name,data.desc)));
                        else
                            $('#response').html($.i18n('hello', AntiXSS.sanitizeInput(data.name,data.desc))); 
                    }
                    else {
                        $('#response').html(AntiXSS.sanitizeInput(data));
                    }
                    $('#nameInput').hide();
  		  fetchIssues();
                    getNames();
                });
            }
        });

        //Retrieve all the visitors from the database
        function getNames(){
          $.get("./api/visitors")
              .done(function(data) {
                  if(data.length > 0) {
                    data.forEach(function(element, index) {
                      data[index] = AntiXSS.sanitizeInput(element)
                    });
                    $('#databaseNames').html($.i18n('database_contents') + JSON.stringify(data));
                  }
              });
          }

          //Call getNames on page load.
          getNames();
}
fetchReview();